package pe.isil.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class Cliente {

    private Integer id;
    private String NomCliente;
    private String ApeCliente;
    private String DNI;
    private String Email;
    private String Telefono;
}
