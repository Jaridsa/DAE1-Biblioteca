package pe.isil.dao;

public class EmpleadoDAO {
}
