package pe.isil.dao;

import pe.isil.model.Cliente;
import pe.isil.util.DatabasUtil;

public class ClienteDAO {

    public static void create(Cliente cliente) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "INSERT INTO Cliente (NomCliente, ApeCliente, DNI, Email, Telefono) values (?, ?, ?, ?, ?) ";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, cliente.getNomCliente());
                statement.setString(2, cliente.getApeCliente());
                statement.setString(3, cliente.getDNI());
                statement.setString(4, cliente.getEmail());
                statement.setString(5, cliente.getTelefono());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }

    }

    public static void update(Cliente cliente) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "UPDATE Cliente SET Email=?, Telefono=? WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, cliente.getEmail());
                statement.setString(2, cliente.getTelefono());
                statement.setInt(3, cliente.getId());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static void delete(Cliente cliente) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "DELETE FROM Cliente  WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, cliente.getId());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static List<Cliente> findAll() {
        List<Cliente> clientes = new ArrayList<>();
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "SELECT * FROM Cliente";
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(sql)) {
                    while (resultSet.next()) {
                        Cliente cliente = new Cliente(
                                resultSet.getId("id"),
                                resultSet.getString("login"),
                                resultSet.getString("password")
                        );
                        clientes.add(cliente);
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return clientes;
    }

    public static Cliente findById(Integer id) {
        Cliente cliente = null;
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "SELECT * FROM Cliente where id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, id);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        cliente = new Cliente(
                                resultSet.getInt("id"),
                                resultSet.getString("login"),
                                resultSet.getString("password")
                        );
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }

        return cliente;
    }

}
