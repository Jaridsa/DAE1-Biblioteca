package pe.isil.dao;

import pe.isil.model.Cliente;
import pe.isil.model.Editorial;
import pe.isil.util.DatabasUtil;

public class EditorialDAO {

    public static void create(Editorial editorial) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "INSERT INTO Editorial (NomEditorial, Pais, AñoPubli) values (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, editorial.getNomEditorial());
                statement.setString(2, editorial.getPais());
                statement.setDate(3, new java.sql.Date(editorial.getAñoPubli().getTime()));
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }

    }

    public static void update(Editorial editorial) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "UPDATE Editorial SET Pais=?, AñoPubli=? WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, editorial.getPais());
                statement.setString(2, editorial.getAñoPubli());
                statement.setInt(3, editorial.getId());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static void delete(Editorial editorial) {
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "DELETE FROM Editorial  WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, editorial.getId());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    public static List<Editorial> findAll() {
        List<Editorial> editoriales = new ArrayList<>();
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "SELECT * FROM Editorial";
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(sql)) {
                    while (resultSet.next()) {
                        Editorial editorial = new Editorial(
                                resultSet.getId("id"),
                                resultSet.getString("login"),
                                resultSet.getString("password")
                        );
                        editoriales.add(editorial);
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return editoriales;
    }

    public static Editorial findById(Integer id) {
        Editorial editorial = null;
        try (Connection connection = DatabasUtil.getConnection()) {
            final String sql = "SELECT * FROM Editorial where id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, id);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        editorial = new Editorial(
                                resultSet.getInt("id"),
                                resultSet.getString("login"),
                                resultSet.getString("password")
                        );
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }

        return editorial;
    }


}
