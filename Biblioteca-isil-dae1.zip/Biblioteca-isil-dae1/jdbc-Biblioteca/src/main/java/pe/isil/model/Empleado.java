package pe.isil.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class Empleado {

    private Integer id;
    private String NomEmpleado;
    private String ApeEmpleado;
    private Date FecNacimiento;
    private String Telefono;

}
