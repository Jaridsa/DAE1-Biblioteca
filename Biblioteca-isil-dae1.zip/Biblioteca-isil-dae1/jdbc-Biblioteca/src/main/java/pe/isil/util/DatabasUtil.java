package pe.isil.util;

public class DatabasUtil {

    private static final String URL = "jdbc:sqlserver:////localhost:5432/javaee_db";
    private static final String USER = "javaee_user";
    private static final String PASSWORD = "javaee_user";
    private static final String DRIVER = "org.postgresql.Driver";

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName(DRIVER);
        return DriverManager.getConnection(URL, USER, PASSWORD);

}
