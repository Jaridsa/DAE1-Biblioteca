package pe.isil.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class Editorial {

    private Integer id;
    private String NomEditorial;
    private String Pais;
    private Date AñoPubli;

}
